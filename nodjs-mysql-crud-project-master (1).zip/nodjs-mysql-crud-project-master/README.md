# CRUD Nodejs and Mysql
This is a basic application crud that uses nodejs in the backend, mysql as database.

# Useful Commands
- to init mysql: `mysql -u root -p` or
  ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'SetRootPasswordHere';

# links
- [bootstrap 4 theme](https://bootswatch.com/4/lux/bootstrap.min.css)
