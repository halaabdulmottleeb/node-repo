import { createPool } from "mysql2/promise";

export const pool = createPool({
  host: "localhost",
  user: "myuser",
  password: "Password123@",
  port: 3306,
  database: "customersdb",
});
